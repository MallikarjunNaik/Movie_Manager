function Movielist() {
    return (
      <div>
        <h2 className="text-blue-500 "> Movies ki list</h2>
        <p className="text-blue-600">The quick brown fox...</p>
      </div>
    );
  }
  
  export default Movielist;
  